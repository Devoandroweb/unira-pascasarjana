<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                &copy; <b>Copyright </b><script>document.write(new Date().getFullYear())</script> Universitas Islam Raden Rahmat. Developer By <b>Era Infinity</b>
            </div>
        </div>
    </div>
</footer>
@include('partials.dashboard.js')