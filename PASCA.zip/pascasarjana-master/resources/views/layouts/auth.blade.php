<!doctype html>
<html lang="en">
@include('partials.auth.head')
<body>
    @yield('content')
    <!-- JS -->
    @include('partials.auth.js')
</body>
</html>
