<!doctype html>
<html lang="en" >
    @include('partials.landing.head')
  <body>
    @include('partials.landing.navbar')
    @yield('content')
    @include('partials.landing.footer')
    
  </body>
</html>
