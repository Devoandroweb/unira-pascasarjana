<?php

return [
    'credentials' => [
        "type" => "service_account",
        "project_id" => "pascasarjana-1995c",
        "private_key_id" => "b28da4f22d8a6d1223467a9cd89516e03a23a25a",
        "private_key" => "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDbrKzfNiEcNmll\nMHcvTwJMvaPe21VaQz89NrkvdLEqW+Rde6MI8g4b2/+IGimdKmH8joIc977YUYaY\nCPSaniFkGsyy3pwYKls6Qk3XmPZOAbQ0GdcVULIfsKg+qBlBOz+2LOJ5IOuQG4OC\nVNpegWjJyEgadGnfQFWCgIiOk9SlM+ME2oGxZArIXL8G0pJtDJ++V4yQdqFA6MCD\nQRYpzYdxqz/rN/CFZ5B/IKmb/dUrLArvtpKKOKnCSELtK+o4C+nVmLPnd6dlei9o\nb9jEkKXQEwBncNnB7M7Tt2j1il55akAvzkLwoYwmamyCul8FpLxfebPx2GOa/hWe\nd+fDYPa9AgMBAAECggEAIdJrPLljzak0VFJq90tjNOzkecqBULLBM4E6b+u331K4\norVc0Q1w+KnIT8HfcwWfLThvy1qln+lQH2u5kBjAAV6oR53t9evc5z0QKR1cRtRi\nVLyUbgFiUMNtPqsOVbRz8cOQDEryRITH8bLI0FDSZnGXZbiowv5vwUuy5WjYuPqE\nBd1zHAUQFDsP/rRUH/x26MmG1zTm3chB2/ybNUjWHLlBz/CCUFYVJJxEAIb6Q4TK\ny+Ae76XXO1MZyinDoITkmyHbKQ5zHqp2l+ogrjRbbcCDyPTJiMEJ9j4m0ZmAcYzZ\nUs+HCwRqWHbsmWLUOcnTjezf51Gs1yOiCgaLaNydLQKBgQD6m9YRF4ZSBqB6V2hn\neyBiTfDx9yXBQ825sABgY5r2vmGmzPX4ci8iiVVkYhxdPKPvM/C02I3NbS4H1ueB\n4oLgsQq7oYxPANqD2jhlXn1zHiLpsUmXlyuoH5EqFnTZjkRpjLkiNCpK4z5HO7cu\n0XK9kJsFbewAGTdJSHr360BfwwKBgQDgZnoK7aLb4SQSTf/eTNy7jQ8Kr3rJIznv\n+hEXsQDYZHwdXwvuZVPGi8AkeBt/MTAWxxckVze49hjkRzxaeXbOzmIwdGzrBDvP\n/s+XyfnR0Wypp+OOgs9+LwAewh6O/3ZghxGHaBIknQMaO7P/uLSr9jWHxOijYwyH\nkp4w885nfwKBgQDx3gM9Xbn6YoDxcnjGHrRDjDu2G7SpkRn1U6MZZCiEaXvvszLV\nxMYvC+KJTpNXfRYu3685qyM4l13snQG0fnuYBeZ47lJvUUCULsFtPEPRHc3OQ5fm\nITU2PrkoqKG/8qmeQP3QwA3tVuKdd0m1etnFkNG87Ljv42ZTaQudSMRJZwKBgBBX\nxkmndvX2lq7ymVDyXh0Wr+LCVvnxI9YTa01DaeFYqCVnd7H8FTbflLXTPYVs6qiu\nBURzSa6h1bxCZ+Xa9MkpBMOspwYSv9xtHWdboWMjkntkq9EEO+Jfv+19i8Y0WsW6\n8I7hCHk8Ki6t7HUSWa4wd0OVFrBXlWEGT5kXGJA3AoGBAOiixMOJAlWYpZ+Y0UnY\n9/WlPIZ9AZkJ9TF3x8+nY7ucVgti5EJM9JcuktWEqi8n8AdMAXS/T5lvAfibIULv\naacrqripKmBwJbv1soeGGrrR/Cqv/cmf+ubYHOiObg0/WQHcKB6N6FGwlhDFGnHx\nl9n9ghseRrEuyGYiGtaqcDl7\n-----END PRIVATE KEY-----\n",
        "client_email" => "firebase-adminsdk-eraxe@pascasarjana-1995c.iam.gserviceaccount.com",
        "client_id" => "100556488526227980197",
        "auth_uri" => "https://accounts.google.com/o/oauth2/auth",
        "token_uri" => "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url" => "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url" => "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-eraxe%40pascasarjana-1995c.iam.gserviceaccount.com",
        "universe_domain" => "googleapis.com"
    ],
    'database_url' => "https://pascasarjana-1995c-default-rtdb.firebaseio.com/",
];
