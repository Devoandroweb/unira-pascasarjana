<?php

return
    [
        "position" => [
            'lecturer',
            'educators'
        ],
        "gender" => ['male', 'female'],
        "role" => ['admin', 'author'],
        "slider_type" => ['image', 'video']
    ];
